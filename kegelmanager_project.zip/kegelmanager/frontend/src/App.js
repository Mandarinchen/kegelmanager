import React from 'react';

function App() {
  return <h1>Kegelmanager läuft!</h1>;
}

export default App;